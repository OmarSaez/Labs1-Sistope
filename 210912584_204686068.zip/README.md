Requisitos tener sistema Linux Ubuntu 24.x.x o superior

Para poder correr el desafio1, primero se debe tener el la misma carpeta el archivo "Makefile" y el codigo en C "desafio1.c"
Seguido en una linea de comandos de Linux Ubuntu se debe ingresas a nivel mismo nivel de la carpeta donde se encuentre los archivos
Tercero en la linea de comandos se debe poner "make" y se creara el ejecutable del desafio1
Por ultimo se debe ingresar "./desafio1 -t (Token) -M (Decremento maximo) -p (cantidad de procesos)"

Nota: Si se busca eliminar el ejecutable se puede poner en la misma linea de comandos "make clean" y se borra 
